// Author Name: Christopher Phillips
// Date: May 31, 2025
// Course ID: CS-320 Software Test
// Description: Task class that represents a single task with validation on ID, name, and description.

package com.example.taskservice;

import java.util.Objects;

public class Task {
    // Fields
    private final String taskId;         // cannot be longer than 10 chars, not null, not updatable
    private String name;                 // cannot be longer than 20 chars, not null
    private String description;          // cannot be longer than 50 chars, not null

    // Constructor
    public Task(String taskId, String name, String description) {
        // Validate taskId
        if (taskId == null) {
            throw new IllegalArgumentException("Task ID cannot be null.");
        }
        if (taskId.length() > 10) {
            throw new IllegalArgumentException("Task ID cannot be longer than 10 characters.");
        }
        this.taskId = taskId;

        // Validate name
        if (name == null) {
            throw new IllegalArgumentException("Name cannot be null.");
        }
        if (name.length() > 20) {
            throw new IllegalArgumentException("Name cannot be longer than 20 characters.");
        }
        this.name = name;

        // Validate description
        if (description == null) {
            throw new IllegalArgumentException("Description cannot be null.");
        }
        if (description.length() > 50) {
            throw new IllegalArgumentException("Description cannot be longer than 50 characters.");
        }
        this.description = description;
    }

    // Getters (no setter for taskId, because it’s final / not updatable)
    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    // Setters for name and description (with validation)
    public void setName(String name) {
        if (name == null) {
            throw new IllegalArgumentException("Name cannot be null.");
        }
        if (name.length() > 20) {
            throw new IllegalArgumentException("Name cannot be longer than 20 characters.");
        }
        this.name = name;
    }

    public void setDescription(String description) {
        if (description == null) {
            throw new IllegalArgumentException("Description cannot be null.");
        }
        if (description.length() > 50) {
            throw new IllegalArgumentException("Description cannot be longer than 50 characters.");
        }
        this.description = description;
    }

    // Override equals() and hashCode() so Task objects can be compared by ID if needed
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Task)) return false;
        Task task = (Task) o;
        return taskId.equals(task.taskId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(taskId);
    }
}
