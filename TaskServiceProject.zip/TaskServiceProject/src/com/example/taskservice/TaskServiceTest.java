// Author Name: Christopher Phillips
// Date: May 31, 2025
// Course ID: CS-320 Software Test
// Description: Unit tests for TaskService class.

package com.example.taskservice;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {

    private TaskService service;

    @BeforeEach
    public void setUp() {
        service = new TaskService();
    }

    @Test
    public void testAddSingleTask() {
        Task t = new Task("task1", "Name1", "Description1");
        service.addTask(t);

        Task fetched = service.getTask("task1");
        assertNotNull(fetched);
        assertEquals("task1", fetched.getTaskId());
        assertEquals("Name1", fetched.getName());
    }

    @Test
    public void testAddMultipleTasks() {
        Task t1 = new Task("t1", "Name1", "Desc1");
        Task t2 = new Task("t2", "Name2", "Desc2");

        service.addTask(t1);
        service.addTask(t2);

        assertNotNull(service.getTask("t1"));
        assertNotNull(service.getTask("t2"));
        assertEquals("Name2", service.getTask("t2").getName());
    }

    @Test
    public void testAddTaskWithDuplicateId() {
        Task t1 = new Task("duplicate", "Name1", "Desc1");
        Task t2 = new Task("duplicate", "OtherName", "OtherDesc");

        service.addTask(t1);
        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(t2);
        });
    }

    @Test
    public void testGetTaskNonExistent() {
        assertNull(service.getTask("nonexistent"));
    }

    @Test
    public void testUpdateTaskName() {
        Task t = new Task("up1", "OldName", "Desc");
        service.addTask(t);

        service.updateTaskName("up1", "NewName");
        assertEquals("NewName", service.getTask("up1").getName());
    }

    @Test
    public void testUpdateTaskNameInvalid() {
        Task t = new Task("up2", "Name", "Desc");
        service.addTask(t);

        // Trying to update name to null should throw
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskName("up2", null);
        });

        // Trying to update name for nonexistent ID should throw
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskName("nonexistent", "Name");
        });
    }

    @Test
    public void testUpdateTaskDescription() {
        Task t = new Task("up3", "Name", "OldDesc");
        service.addTask(t);

        service.updateTaskDescription("up3", "NewDescription");
        assertEquals("NewDescription", service.getTask("up3").getDescription());
    }

    @Test
    public void testUpdateTaskDescriptionInvalid() {
        Task t = new Task("up4", "Name", "Desc");
        service.addTask(t);

        // Update description to null → exception
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskDescription("up4", null);
        });

        // Update description on nonexistent ID → exception
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskDescription("nope", "Desc");
        });
    }

    @Test
    public void testDeleteTask() {
        Task t = new Task("del1", "Name", "Desc");
        service.addTask(t);
        assertNotNull(service.getTask("del1"));

        service.deleteTask("del1");
        assertNull(service.getTask("del1"));
    }

    @Test
    public void testDeleteTaskInvalid() {
        // Deleting nonexistent ID → exception
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteTask("doesntExist");
        });
    }
}
