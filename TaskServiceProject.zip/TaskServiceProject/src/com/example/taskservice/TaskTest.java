// Author Name: Christopher Phillips
// Date: May 31, 2025
// Course ID: CS-320 Software Test
// Description: Unit tests for Task class.

package com.example.taskservice;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {

    @Test
    public void testCreateValidTask() {
        Task t = new Task("1234567890", "My Task", "This is a valid description.");
        assertEquals("1234567890", t.getTaskId());
        assertEquals("My Task", t.getName());
        assertEquals("This is a valid description.", t.getDescription());
    }

    @Test
    public void testTaskIdTooLong() {
        // 11 characters is invalid (> 10)
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("ABCDEFGHIJK", "Name", "Desc");
        });
    }

    @Test
    public void testTaskIdNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Name", "Desc");
        });
    }

    @Test
    public void testNameTooLong() {
        // 21 characters is invalid (> 20)
        String longName = "ABCDEFGHIJKLMNOPQRSTU"; // 21 chars
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", longName, "Valid description");
        });
    }

    @Test
    public void testNameNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", null, "Valid description");
        });
    }

    @Test
    public void testDescriptionTooLong() {
        // 51 characters is invalid (> 50)
        String longDesc = "ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZ1"; // 53 chars
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Name", longDesc);
        });
    }

    @Test
    public void testDescriptionNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Name", null);
        });
    }

    @Test
    public void testSetNameValid() {
        Task t = new Task("id01", "Original", "Desc");
        t.setName("NewName");
        assertEquals("NewName", t.getName());
    }

    @Test
    public void testSetNameTooLong() {
        Task t = new Task("id02", "Original", "Desc");
        String longName = "ABCDEFGHIJKLMNOPQRSTU"; // 21 chars
        assertThrows(IllegalArgumentException.class, () -> {
            t.setName(longName);
        });
    }

    @Test
    public void testSetNameNull() {
        Task t = new Task("id03", "Original", "Desc");
        assertThrows(IllegalArgumentException.class, () -> {
            t.setName(null);
        });
    }

    @Test
    public void testSetDescriptionValid() {
        Task t = new Task("id04", "Name", "OriginalDesc");
        t.setDescription("New valid description");
        assertEquals("New valid description", t.getDescription());
    }

    @Test
    public void testSetDescriptionTooLong() {
        Task t = new Task("id05", "Name", "OriginalDesc");
        // 51‐char string
        String longDesc = "ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZ1";
        assertThrows(IllegalArgumentException.class, () -> {
            t.setDescription(longDesc);
        });
    }

    @Test
    public void testSetDescriptionNull() {
        Task t = new Task("id06", "Name", "OrigDesc");
        assertThrows(IllegalArgumentException.class, () -> {
            t.setDescription(null);
        });
    }
}
