// Author Name: Christopher Phillips
// Date: May 31, 2025
// Course ID: CS-320 Software Test
// Description: TaskService manages Task objects in memory. Allows add, delete, and update per Task ID.

package com.example.taskservice;

import java.util.HashMap;
import java.util.Map;

public class TaskService {
    // Use a HashMap to store tasks by their ID for fast lookup
    private final Map<String, Task> tasks;

    public TaskService() {
        tasks = new HashMap<>();
    }

    /**
     * Adds a new Task to the service.
     * @param task the Task to add
     * @throws IllegalArgumentException if a Task with the same ID already exists
     */
    public void addTask(Task task) {
        if (task == null) {
            throw new IllegalArgumentException("Task cannot be null.");
        }
        String id = task.getTaskId();
        if (tasks.containsKey(id)) {
            throw new IllegalArgumentException("A task with ID '" + id + "' already exists.");
        }
        tasks.put(id, task);
    }

    /**
     * Deletes the Task with the given ID.
     * @param taskId the ID of the task to delete
     * @throws IllegalArgumentException if no Task with the ID is found
     */
    public void deleteTask(String taskId) {
        if (taskId == null) {
            throw new IllegalArgumentException("Task ID cannot be null.");
        }
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("No task with ID '" + taskId + "' exists.");
        }
        tasks.remove(taskId);
    }

    /**
     * Updates the name of the Task with the given ID.
     * @param taskId the ID of the task
     * @param newName the new name to set
     * @throws IllegalArgumentException if no Task with the ID is found, or if newName is invalid
     */
    public void updateTaskName(String taskId, String newName) {
        if (taskId == null) {
            throw new IllegalArgumentException("Task ID cannot be null.");
        }
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("No task with ID '" + taskId + "' exists.");
        }
        // This will validate newName inside setName() and throw if invalid
        task.setName(newName);
    }

    /**
     * Updates the description of the Task with the given ID.
     * @param taskId the ID of the task
     * @param newDescription the new description to set
     * @throws IllegalArgumentException if no Task with the ID is found, or if newDescription is invalid
     */
    public void updateTaskDescription(String taskId, String newDescription) {
        if (taskId == null) {
            throw new IllegalArgumentException("Task ID cannot be null.");
        }
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("No task with ID '" + taskId + "' exists.");
        }
        // This will validate newDescription inside setDescription() and throw if invalid
        task.setDescription(newDescription);
    }

    /**
     * Retrieves the Task with the given ID.
     * @param taskId the ID of the task
     * @return the Task object, or null if not found
     */
    public Task getTask(String taskId) {
        if (taskId == null) {
            throw new IllegalArgumentException("Task ID cannot be null.");
        }
        return tasks.get(taskId);
    }
}
