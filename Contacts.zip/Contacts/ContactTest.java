import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    public void testValidContactCreation() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St, Springfield");
        Assertions.assertEquals("1234567890", contact.getContactId());
        Assertions.assertEquals("John", contact.getFirstName());
        Assertions.assertEquals("Doe", contact.getLastName());
        Assertions.assertEquals("1234567890", contact.getPhone());
        Assertions.assertEquals("123 Main St, Springfield", contact.getAddress());
    }

    @Test
    public void testInvalidContactIdTooLong() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "John", "Doe", "1234567890", "123 Main St");
        });
    }

    @Test
    public void testNullFields() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "John", "Doe", "1234567890", "123 Main St");
        });
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", null, "Doe", "1234567890", "123 Main St");
        });
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "John", null, "1234567890", "123 Main St");
        });
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "John", "Doe", null, "123 Main St");
        });
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "John", "Doe", "1234567890", null);
        });
    }

    @Test
    public void testUpdateFields() {
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "Address");
        contact.setFirstName("Jane");
        contact.setLastName("Smith");
        contact.setPhone("0987654321");
        contact.setAddress("456 Elm St");

        Assertions.assertEquals("Jane", contact.getFirstName());
        Assertions.assertEquals("Smith", contact.getLastName());
        Assertions.assertEquals("0987654321", contact.getPhone());
        Assertions.assertEquals("456 Elm St", contact.getAddress());
    }

    @Test
    public void testUpdateInvalidFields() {
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "Address");
        Assertions.assertThrows(IllegalArgumentException.class, () -> contact.setFirstName(null));
        Assertions.assertThrows(IllegalArgumentException.class, () -> contact.setLastName(null));
        Assertions.assertThrows(IllegalArgumentException.class, () -> contact.setPhone("123"));
        Assertions.assertThrows(IllegalArgumentException.class, () -> contact.setAddress(null));
    }
}
