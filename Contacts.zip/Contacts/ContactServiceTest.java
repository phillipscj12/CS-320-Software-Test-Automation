import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {
    private ContactService service;
    private Contact contact;

    @BeforeEach
    public void setUp() {
        service = new ContactService();
        contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);
    }

    @Test
    public void testAddContact() {
        Contact newContact = new Contact("2", "Jane", "Smith", "0987654321", "456 Elm St");
        service.addContact(newContact);
        Assertions.assertEquals(newContact, service.getContactById("2"));
    }

    @Test
    public void testAddDuplicateContactId() {
        Contact duplicate = new Contact("1", "Jane", "Smith", "0987654321", "456 Elm St");
        Assertions.assertThrows(IllegalArgumentException.class, () -> service.addContact(duplicate));
    }

    @Test
    public void testDeleteContact() {
        service.deleteContact("1");
        Assertions.assertNull(service.getContactById("1"));
    }

    @Test
    public void testDeleteNonExistentContact() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> service.deleteContact("999"));
    }

    @Test
    public void testUpdateContact() {
        service.updateFirstName("1", "Jane");
        service.updateLastName("1", "Smith");
        service.updatePhone("1", "0987654321");
        service.updateAddress("1", "789 Oak St");

        Contact updated = service.getContactById("1");
        Assertions.assertEquals("Jane", updated.getFirstName());
        Assertions.assertEquals("Smith", updated.getLastName());
        Assertions.assertEquals("0987654321", updated.getPhone());
        Assertions.assertEquals("789 Oak St", updated.getAddress());
    }

    @Test
    public void testUpdateNonExistentContact() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> service.updateFirstName("999", "Foo"));
    }
}
