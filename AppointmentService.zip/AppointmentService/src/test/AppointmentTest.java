// Author Name: Christopher Phillips
// Date: June 06, 2025
// Course ID: CS-320 Software Test
// Description: Unit tests for the Appointment class, covering:
// * - Successful creation with valid inputs
// * - Validation failures for null or out-of-range IDs, dates, and descriptions
// * - Correct behavior of update methods for date and description



import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Calendar;
import java.util.Date;

public class AppointmentTest {

    // Helper to get a future date
    private Date futureDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, 1);
        return cal.getTime();
    }

    @Test
    public void validConstruction() {
        Date date = futureDate();
        Appointment a = new Appointment("ID123", date, "Checkup");
        assertEquals("ID123", a.getAppointmentId());
        assertEquals(date, a.getAppointmentDate());
        assertEquals("Checkup", a.getDescription());
    }

    @Test
    public void idNullThrows() {
        assertThrows(IllegalArgumentException.class,
                () -> new Appointment(null, futureDate(), "Desc"));
    }

    @Test
    public void idTooLongThrows() {
        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("ABCDEFGHIJK", futureDate(), "Desc"));
    }

    @Test
    public void dateNullThrows() {
        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("ID1", null, "Desc"));
    }

    @Test
    public void dateInPastThrows() {
        Date past = new Date(System.currentTimeMillis() - 1000);
        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("ID1", past, "Desc"));
    }

    @Test
    public void descriptionNullThrows() {
        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("ID1", futureDate(), null));
    }

    @Test
    public void descriptionTooLongThrows() {
        String longDesc = "x".repeat(51);
        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("ID1", futureDate(), longDesc));
    }

    // If you implemented setters:
    @Test
    public void updateDateWorks() {
        Appointment a = new Appointment("ID1", futureDate(), "Desc");
        Date newDate = futureDate();
        a.setAppointmentDate(newDate);
        assertEquals(newDate, a.getAppointmentDate());
    }

    @Test
    public void updateDescWorks() {
        Appointment a = new Appointment("ID1", futureDate(), "Desc");
        a.setDescription("New description");
        assertEquals("New description", a.getDescription());
    }
}
