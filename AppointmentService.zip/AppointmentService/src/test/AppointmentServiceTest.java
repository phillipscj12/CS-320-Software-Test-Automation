// Author Name: Christopher Phillips
// Date: June 06, 2025
// Course ID: CS-320 Software Test
// Description: Unit tests for the AppointmentService class, verifying:
// * - Adding and retrieving appointments by unique ID
// * - Proper exception when adding a duplicate appointment
// * - Successful deletion of existing appointments
// * - Safe handling of deletion requests for non-existent IDs

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Calendar;
import java.util.Date;

public class AppointmentServiceTest {
    private AppointmentService service;
    private Appointment sample;

    @BeforeEach
    public void setup() {
        service = new AppointmentService();
        // Use the same helper approach
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, 1);
        sample = new Appointment("A1", cal.getTime(), "Meeting");
    }

    @Test
    public void addAndGetAppointment() {
        service.addAppointment(sample);
        Appointment fetched = service.getAppointment("A1");
        assertNotNull(fetched);
        assertEquals("Meeting", fetched.getDescription());
    }

    @Test
    public void addDuplicateThrows() {
        service.addAppointment(sample);
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(sample));
    }

    @Test
    public void deleteAppointmentRemovesIt() {
        service.addAppointment(sample);
        service.deleteAppointment("A1");
        assertNull(service.getAppointment("A1"));
    }

    @Test
    public void deleteNonExistentDoesNothing() {
        // Should not throw
        assertDoesNotThrow(() -> service.deleteAppointment("NoSuchID"));
    }
}
