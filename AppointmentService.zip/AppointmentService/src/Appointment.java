// Author Name: Christopher Phillips
// Date: June 06, 2025
// Course ID: CS-320 Software Test
// Description: Represents an appointment with a unique ID, a future date, and a brief description.
// * Enforces that the ID is non‐null and ≤10 characters, the date is non‐null and not in the past,
// * and the description is non‐null and ≤50 characters.

import java.util.Date;

public class Appointment {
    private final String appointmentId;
    private Date appointmentDate;
    private String description;

    public Appointment(String appointmentId, Date appointmentDate, String description) {
        // ID validations
        if (appointmentId == null || appointmentId.length() > 10) {
            throw new IllegalArgumentException("ID must be non-null and at most 10 characters");
        }
        this.appointmentId = appointmentId;

        // Date validations
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Date must be non-null and not in the past");
        }
        this.appointmentDate = appointmentDate;

        // Description validations
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Description must be non-null and at most 50 characters");
        }
        this.description = description;
    }

    // getters
    public String getAppointmentId() { return appointmentId; }
    public Date getAppointmentDate() { return new Date(appointmentDate.getTime()); }
    public String getDescription() { return description; }

    // Optional: setters for date and description if you plan to allow updates
    public void setAppointmentDate(Date newDate) {
        if (newDate == null || newDate.before(new Date())) {
            throw new IllegalArgumentException("Date must be non-null and not in the past");
        }
        this.appointmentDate = newDate;
    }

    public void setDescription(String newDescription) {
        if (newDescription == null || newDescription.length() > 50) {
            throw new IllegalArgumentException("Description must be non-null and at most 50 characters");
        }
        this.description = newDescription;
    }
}

