// Author Name: Christopher Phillips
// Date: June 06, 2025
// Course ID: CS-320 Software Test
// Description: Manages Appointment objects in an in-memory map keyed by their unique IDs.
// * Supports adding new appointments (ensuring IDs are unique), deleting
// * appointments by ID, and retrieving appointments for verification or testing.


import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
    private final Map<String, Appointment> appointments = new HashMap<>();

    // Add a new appointment; ID must be unique
    public void addAppointment(Appointment appt) {
        if (appointments.containsKey(appt.getAppointmentId())) {
            throw new IllegalArgumentException("Appointment ID already exists");
        }
        appointments.put(appt.getAppointmentId(), appt);
    }

    // Delete an appointment by ID
    public void deleteAppointment(String appointmentId) {
        appointments.remove(appointmentId);
    }

    // Optional: retrieve an appointment (for testing)
    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }
}
